
public interface IUpdatable
{
    void OnUpdateView();
}
